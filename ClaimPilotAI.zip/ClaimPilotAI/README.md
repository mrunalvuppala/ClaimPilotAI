# ClaimPilot AI

This is a prototype for ClaimPilot AI, a hackathon project built with React (frontend) and FastAPI (backend).

## How to Run

### Backend
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
```

### Frontend
```bash
cd frontend
npm install
npm start
```

### Sample File
Use the sample in `sample_data/sample837.txt` to test file upload.
