from fastapi import FastAPI, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

# Allow frontend to access backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    contents = await file.read()
    text = contents.decode("utf-8", errors="ignore")

    # Dummy logic to mimic AI analysis
    if "CLM" in text:
        result = "Claim contains valid CLM segment. Likely a proper X12 837."
    else:
        result = "Missing CLM segment. Possible formatting issue."

    return {"message": result}
